<?php
/*
Template Name: Filmographie
*/
get_header();
?>

<div class="container">
    <h1 class="title">Ma Filmographie</h1>

    <div class="films">
        <div class="film-card">
            <img src="<?php echo get_template_directory_uri(); ?>/source/oppenheimer.jpg" alt="Film 1" class="film-image">
            <div class="film-info">
                <h2 class="film-title">Oppenheimer</h2>
                <p class="film-release">2023</p>
                <p class="film-director">Par Christopher Nolan</p>
            </div>
        </div>

        <div class="film-card">
            <img src="<?php echo get_template_directory_uri(); ?>/source/labyrinthe.jpg" alt="Film 2" class="film-image">
            <div class="film-info">
                <h2 class="film-title">Le labyrinthe</h2>
                <p class="film-release">2014</p>
                <p class="film-director">Par Wess Ball</p>
            </div>
        </div>

        <div class="film-card">
            <img src="<?php echo get_template_directory_uri(); ?>/source/lalaland.jpg" alt="Film 3" class="film-image">
            <div class="film-info">
                <h2 class="film-title">La La Land</h2>
                <p class="film-release">2017</p>
                <p class="film-director">Par Damien Chazelle</p>
            </div>
        </div>

        <div class="film-card">
            <img src="<?php echo get_template_directory_uri(); ?>/source/budapest.webp" alt="Film 4" class="film-image">
            <div class="film-info">
                <h2 class="film-title">Grand Budapest Hotel</h2>
                <p class="film-release">2014</p>
                <p class="film-director">Par Wes Anderson</p>
            </div>
        </div>

        <div class="film-card">
            <img src="<?php echo get_template_directory_uri(); ?>/source/littlemisssunshine.jpg" alt="Film 5" class="film-image">
            <div class="film-info">
                <h2 class="film-title">Little Miss Sunshine</h2>
                <p class="film-release">2006</p>
                <p class="film-director">Par Jonathan Dayton</p>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
