<?php
// Redirection vers la page d'accueil
if (is_front_page()) {
    get_template_part('accueil'); // Charge home.php
} else {
    get_template_part('page'); // Charge page.php pour les autres pages
}
?> 