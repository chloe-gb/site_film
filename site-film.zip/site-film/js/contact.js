document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();//empeche le rafraichiement 
    let message = document.getElementById('message');
    message.style.display = 'block';//affiche le message 
    setTimeout(() => { message.style.display = 'none'; }, 3000);//pendant 3 sec
    this.reset();//remet a zero
});