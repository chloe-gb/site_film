<footer>
    <div class="footer">
        <div id="toggleFooter">
            <svg class="close" width="40" height="40" viewBox="0 0 50 50">
                <g stroke="white" stroke-width="6">
                    <line x1="10" y1="10" x2="40" y2="40"></line>
                    <line x1="40" y1="10" x2="10" y2="40"></line>
                </g>
            </svg>
        </div>
        <div id="footerContent">
            <div class="footer_center">
                <ul>
                    <li>@Clément PILLON</li>
                    <li>@Meryem KUTLU</li>
                    <li>@Chloé GUYON-BLANC</li>
                </ul>
            </div>
        </div>
    </div>

    <?php wp_footer(); // Indispensable pour WordPress ?>
</footer>
</body>
</html>
