<?php
/*
Template Name: Actualités
*/
get_header(); 
?>

<main class="container">
    <h1 class="title">Actualités d'Aquila</h1>
    <section class="mainactu">
        <article class="artactu">
            <div class="titreimage" style="background-image: url('<?php echo get_template_directory_uri(); ?>/IMG/actu1.png');">
                <h3>11 <br> 03 <br> 2025</h3>
            </div>
            <div class="textactu">
                <h2>Prochainement sur Aquila : Votre agenda des nouveautés du mois d'avril</h2>
                <ul>
                    <li>1er avril : "Le Secret de l'Opale" (Film d'aventure)</li>
                    <li>7 avril : "Souvenirs Volés" (Drame poignant)</li>
                    <li>15 avril : "Écho des Abysses" (Documentaire fascinant)</li>
                    <li>20 avril : "Les Chroniques du Néant" (Série événement)</li>
                </ul>
                🎯 Ajoutez ces dates à votre agenda et préparez-vous à découvrir des pépites cinématographiques !
            </div>
        </article>

        <article class="artactu">
            <div class="titreimage" style="background-image: url('<?php echo get_template_directory_uri(); ?>/IMG/actu2.png');">
                <h3>08 <br> 03 <br> 2025</h3>

   <?php get_footer(); ?>