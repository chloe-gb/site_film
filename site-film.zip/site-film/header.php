<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> - <?php wp_title(); ?></title>

    <?php wp_head(); // Important pour charger les styles et scripts de WordPress ?>
</head>

<body <?php body_class(); ?>>

<header>
    <div>
        <input id="test" type="checkbox" />
        <label for="test">
            <svg class="burger" width="86" height="60" viewbox="0 0 150 150">
                <g stroke-width="12">
                    <line x1="6" y1="6" x2="80" y2="6"></line>
                    <line x1="6" y1="28" x2="80" y2="28"></line>
                    <line x1="6" y1="50" x2="80" y2="50"></line>
                </g>
            </svg>
            <svg class="close" width="86" height="60" viewbox="0 0 150 150">
                <g stroke-width="12">
                    <line x1="42" y1="6" x2="42" y2="80"></line>
                    <line x1="6" y1="42" x2="80" y2="42"></line>
                </g>
            </svg>
        </label>

        <div class="menu">
            <h1 class="titre"><?php bloginfo('name'); ?></h1>
            <hr style="width:100vw;">

            <nav>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'menu-principal',
                    'container'      => false,
                    'menu_class'     => 'navigation'
                ));
                ?>
            </nav>
        </div>
    </div>

    <h1 class="page"><?php bloginfo('name'); ?></h1>
    <img class="logo" src="<?php echo get_template_directory_uri(); ?>/logo.png" alt="logo">
</header>

<hr style="width:100vw;">
