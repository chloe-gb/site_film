<?php 
/*
Template Name: Accueil
*/
get_header(); ?>

<!-- Section À propos -->
<section class="about">
    <div class="about-content">
        <img class="about-img" src="<?php echo get_template_directory_uri(); ?>/source/pexels-kyleloftusstudios-3379934.jpg" alt="À propos de nous">
        <div class="about-text">
            <h2>Qui sommes-nous ?</h2>
            <p>Notre plateforme a été conçue pour offrir une <strong>expérience de streaming optimale</strong>, avec une interface intuitive et facile à utiliser...</p>
        </div>
    </div>
</section>

<!-- Section Nos Valeurs -->
<section class="values">
    <h2>Nos Valeurs</h2>
    <div class="value-box">
        <div class="value">
            <h3>Innovation 🚀</h3>
            <p>Nous croyons fermement que l'innovation est essentielle...</p>
        </div>
        <div class="value">
            <h3>Accessibilité 🌍</h3>
            <p>Nous nous engageons à rendre notre plateforme accessible à tous...</p>
        </div>
        <div class="value">
            <h3>Engagement 🤝</h3>
            <p>Nous mettons un point d'honneur à offrir un service fiable...</p>
        </div>
    </div>
</section>

<!-- Section Pourquoi choisir notre plateforme ? -->
<section class="purpose">
    <div class="purpose-content">
        <div class="purpose-text">
            <h2>Pourquoi choisir notre plateforme ?</h2>
            <p>Notre plateforme de streaming se distingue par sa diversité de contenu...</p>
        </div>
        <img class="purpose-img" src="<?php echo get_template_directory_uri(); ?>/source/pexels-adrien-olichon-1257089-3709369.jpg" alt="Streaming de films">
    </div>
</section>

<!-- Section Nos Genres de Films -->
<section class="genres">
    <h2>Nos Genres de Films</h2>
    <div class="genres-list">
        <ul>
            <li><strong>Action 🔥</strong>: Des films palpitants...</li>
            <li><strong>Comédie 😄</strong>: Laissez-vous emporter...</li>
            <li><strong>Drame 🎭</strong>: Des films poignants...</li>
        </ul>
    </div>
</section>

<?php get_footer(); ?>
